---
name: eks-node-diagnostics
description: >
  Use this skill to investigate and troubleshoot EKS worker node
  problems by collecting OS-level diagnostic logs and following
  structured runbooks. Activate when: a node goes NotReady or shows
  conditions like MemoryPressure or DiskPressure, pods are stuck in
  ContainerCreating or CrashLoopBackOff on a specific node, networking
  is broken (DNS timeouts, services unreachable via ClusterIP, pods
  can't talk to each other, packet loss or latency), volumes won't
  attach or mount (EBS timeouts, EFS NFS errors, CSI driver issues),
  containers are OOM-killed, or the user says something is wrong with
  an EKS node without naming specific symptoms. Also activate when the
  user wants to inspect node-level artifacts like iptables rules, VPC
  CNI configuration, route tables, kernel logs, or wants to capture
  live network traffic from a node or pod.
compatibility: >
  Requires the EKS Node Diagnostics MCP server deployed and configured
  in the Agent Space. Nodes must have SSM Agent running.
---

# EKS Node Diagnostics

## When to use

Any EKS worker node investigation where kubectl and CloudWatch are insufficient — iptables rules, CNI config, route tables, dmesg, IPAMD logs, conntrack state, EBS/EFS CSI driver logs, ENA metadata.

## Investigation workflow

### Step 1 — Collect and triage (two calls)

```
collect(instanceId="<id>", region="<region>")
status(executionId="<id>")          # poll until Success
quick_triage(instanceId="<id>")     # one-shot: validate + errors + root cause + SOPs
```

`quick_triage` returns:
- `rootCause`: category + confidence (8 categories)
- `topEvidence`: actual log excerpts — no need to call `search` afterward
- `recommendedSOPs`: auto-matched runbooks — call `get_sop` for each
- `prerequisiteChecks`: is aws-node / kube-proxy / CoreDNS / CSI running?
- `investigationHints`: guidance to avoid rabbit-holing

If a prerequisite is missing, that IS the root cause. Don't chase downstream symptoms.

### Step 2 — Domain deep dive (only if needed)

```
# Networking
network_diagnostics(instanceId="<id>", sections="iptables,cni,routes,dns,eni,ipamd")

# Storage
storage_diagnostics(instanceId="<id>", sections="kubelet,ebs_csi,efs_csi,pv_pvc,instance")

# Live packet capture (when logs are inconclusive)
tcpdump_capture(instanceId="<id>", filter="port 53", durationSeconds=120)
tcpdump_analyze(instanceId="<id>", commandId="<id>")
```

Read `references/storage-guardrails.md` before concluding on any storage issue.
Read `references/cni-claim-enforcement.md` before making any VPC CNI behavioral claim.

### Step 3 — Detailed path (low-confidence cases only)

```
errors → search → correlate → read → summarize
```

Use `search` only for specific patterns not in `topEvidence`. Use `read` only for full file content. Always pass finding IDs (F-NNN, S-NNN) to `summarize`.

## Tool quick reference

| Tool | When to use |
|------|-------------|
| `collect` | Start log collection (async, 1-3 min) |
| `status` | Poll collection progress |
| `quick_triage` | FASTEST root cause — use this first |
| `errors` | Pre-indexed findings with severity filter |
| `search` | Regex search when topEvidence is insufficient |
| `correlate` | Cross-file timeline around a pivot event |
| `read` | Stream raw log content (no truncation) |
| `summarize` | Grounded summary from finding IDs |
| `network_diagnostics` | Structured iptables/CNI/routes/DNS/ENI/IPAMD analysis |
| `storage_diagnostics` | Structured kubelet/EBS-CSI/EFS-CSI/PV-PVC/instance analysis |
| `tcpdump_capture` | Live packet capture (supports pod-level via crictl) |
| `tcpdump_analyze` | 15 analysis modules: DNS, RST, DNAT, SNAT, retransmissions, etc. |
| `cluster_health` | Enumerate nodes, check SSM Agent, flag unhealthy |
| `compare_nodes` | Diff findings between 2+ nodes |
| `batch_collect` | Smart sampling for large clusters |
| `batch_status` | Poll multiple collections |
| `validate` | Verify bundle completeness |
| `artifact` | Presigned URL for large files (15-min expiry) |
| `history` | Past collections audit trail |
| `list_sops` | Browse all 41 runbooks |
| `get_sop` | Fetch full runbook procedure |

## Gotchas: VPC CNI

These are the mistakes agents make most often. Full details in `references/cni-claim-enforcement.md`.

- `POD_SECURITY_GROUP_ENFORCING_MODE=strict` does NOT create default-deny. Only affects pods with `vpc.amazonaws.com/pod-eni` annotation. Unannotated pods are completely unaffected.
- CNI does NOT manage KUBE-SERVICES. Service routing is 100% kube-proxy. If KUBE-SERVICES is empty, kube-proxy is broken — not the CNI.
- `AWS_VPC_K8S_CNI_EXTERNALSNAT=true` does NOT break service routing. It only removes the CNI's SNAT chain. kube-proxy masquerade is independent.
- `ENABLE_PREFIX_DELEGATION` does NOT change routing or iptables. Only changes IP allocation strategy.
- IPv6 mode has NO SNAT rules by design. Missing AWS-SNAT-CHAIN-0 is expected.
- All CNI config is node-local (os.Getenv). Never claim cluster-wide effect.
- `NETWORK_POLICY_ENFORCING_MODE` ≠ `POD_SECURITY_GROUP_ENFORCING_MODE`. Completely different subsystems.
- Missing KUBE-SVC chains in IPVS mode is NORMAL. Check `ipvsadm -L` instead.
- Transient "IP not in datastore" during 30s cooldown is NORMAL. Don't restart aws-node.
- `nm-cloud-setup` (table 30200/30400) is INCOMPATIBLE with VPC CNI.

### Chain ownership

| Chain | Owner |
|-------|-------|
| AWS-SNAT-CHAIN-0, AWS-CONNMARK-CHAIN-0 | VPC CNI |
| KUBE-SERVICES, KUBE-SVC-*, KUBE-SEP-*, KUBE-POSTROUTING | kube-proxy |

### Connmark space

| Component | Mark |
|-----------|------|
| VPC CNI | 0x80 |
| kube-proxy | 0x0000c000 |
| Calico | 0xffff0000 |

## Gotchas: Storage

Full details in `references/storage-guardrails.md`.

- Multi-Attach 6-minute delay after pod termination is NORMAL K8s behavior, not a CSI bug.
- EBS and ENI share attachment slots on pre-Gen7 instances (m5/c5/r5). VPC CNI ENIs consume EBS slots.
- IMDSv2 hop limit must be >=2 for containerized CSI drivers.
- EFS PV/PVC capacity is meaningless — EFS is elastic.
- EC2 API throttling from CSI sidecars affects the entire account/region.

## Anti-hallucination rules

1. Always cite finding IDs (F-NNN, S-NNN). `summarize` flags unresolved IDs.
2. Findings with `is_baseline: true` are known noise — acknowledge, don't treat as incident-specific.
3. `correlate` reports confidence and data gaps. State them explicitly.
4. Time-bounded: default 10 min, max 24 hours. Use `incident_time` to override.
5. Spend no more than 2 minutes on any single hypothesis. Pivot if inconclusive.

## 41 runbooks

`quick_triage`, `network_diagnostics`, and `storage_diagnostics` auto-recommend SOPs. Use `get_sop(sopName="<id>")` to fetch full procedures.

| Category | IDs | Covers |
|----------|-----|--------|
| A — Node Lifecycle | A1-A4 | OOM/NotReady, certs, bootstrap, clock skew |
| B — Kubelet | B1-B3 | Config, eviction, PLEG |
| C — Runtime | C1-C3 | Image pull, sandbox, inode |
| D — Networking | D1-D9 | CNI, kube-proxy, conntrack, MTU, DNS, ENA, pod-to-pod |
| E — Storage | E1-E2 | EBS CSI, EFS mount |
| F — Scheduling | F1-F3 | CPU/mem, max pods, taints |
| G — Pressure | G1-G3 | Disk, OOMKill, PID |
| H — IAM | H1-H3 | Node role, IRSA, IMDS |
| I — Upgrades | I1 | Version skew |
| J — Infra | J1-J3 | ENA limits, EBS transient, AZ outage |
| K — Workload | K1-K5 | Terminating, probes, CrashLoop, containerd, CSI plugin |
| Z — Catch-All | Z1 | General troubleshooting |
