# EKS Storage Anti-Misdiagnosis Guardrails

Read these guardrails BEFORE concluding on any EKS storage/volume/CSI issue.

## Guardrail 1: Multi-Attach 6-Minute Delay is Normal
After unclean pod termination, Kubernetes waits ~6 minutes (maxWaitForUnmountDuration) before force-detaching an EBS volume. This is NORMAL K8s behavior, NOT a CSI driver bug. Check `Node.Status.VolumesInUse` on the old node.

## Guardrail 2: EBS/ENI Shared Attachment Slots (Pre-Gen7)
On pre-Gen7 instances (m5, c5, r5, etc.), ENIs and EBS volumes share attachment slots. VPC CNI attaches secondary ENIs for pod IPs — each ENI consumes an EBS slot. If volume attach fails with "maximum number of volumes already attached", check ENI count. Fix: enable prefix delegation (fewer ENIs), use `--reserved-volume-attachments`, or upgrade to Gen7+ (m7i, c7g — dedicated EBS limits).

## Guardrail 3: IMDSv2 Hop Limit
IMDSv2 hop limit must be >=2 for containerized CSI drivers. EBS/EFS CSI node DaemonSets run in containers and need 2 hops to reach IMDS. With hop limit=1, CSI drivers can't get instance metadata. Fix: `aws ec2 modify-instance-metadata-options --http-put-response-hop-limit 2`.

## Guardrail 4: ebs.csi.aws.com/agent-not-ready Taint
This taint prevents pods from scheduling before the EBS CSI node DaemonSet is ready. If pods are stuck Pending with this taint, check that the EBS CSI node DaemonSet is running and healthy.

## Guardrail 5: XFS Compatibility
XFS "wrong fs type, bad superblock" on Amazon Linux 2 with newer xfsprogs is a KNOWN ISSUE. Fix: set `--legacy-xfs=true` on the EBS CSI node DaemonSet args.

## Guardrail 6: EFS Capacity is Meaningless
EFS is elastic and ignores the PV/PVC capacity value. The capacity field is required by Kubernetes but NOT enforced by EFS. Do NOT flag EFS capacity mismatches as issues.

## Guardrail 7: EFS Dynamic Provisioning = Access Points
CSI driver creates access points (up to 1000 per file system). The EFS file system itself must be pre-created — CSI driver only manages access points. Each PV maps to one access point.

## Guardrail 8: In-Tree Provisioner Migration
StorageClass with provisioner `kubernetes.io/aws-ebs` uses the deprecated in-tree driver. CSI migration feature gates translate this to `ebs.csi.aws.com` at runtime. Kubelet MUST be drained before changing CSI migration feature gates.

## Guardrail 9: EC2 API Throttling is Account-Wide
High `--worker-threads` in CSI sidecars (external-provisioner, external-attacher) can exhaust EC2 API quota for ALL instances in the account/region, not just one node. Symptoms: CreateVolume/AttachVolume/DetachVolume timeouts across multiple nodes simultaneously.

## Guardrail 10: Network Policies Block CSI
Network policies in strict mode can block CSI driver communication. EBS CSI controller needs HTTPS 443 to EC2 API. EFS CSI node needs NFS port 2049 to mount targets.

## Guardrail 11: Cross-VPC EFS Needs Botocore
For cross-VPC EFS mounts, install botocore in the EFS CSI driver container. Without botocore, DNS resolution for mount targets in other VPCs will fail.
